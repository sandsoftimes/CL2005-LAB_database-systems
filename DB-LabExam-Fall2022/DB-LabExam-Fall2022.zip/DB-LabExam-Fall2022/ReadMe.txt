MySQL
To import the database use the following source command.

For Windows
source C:\Users\exam\Desktop\DataSets\sailors.sql

For Linux
source /media/usman/Data/FAST/sailors.sql



MongoDB
Import the json file into mongodb collection(movie) by issuing the following command.

mongoimport --db zain_8743 --collection movie --file C\Users\exam\Desktop\Database\movies.json
use appropriate path location if you are using Linux.

alternatively, you could import the collections using MongoDB Compass as well.

